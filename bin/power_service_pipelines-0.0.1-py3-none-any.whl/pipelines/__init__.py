# This version will be replaced in our CI process later
__version__ = "0.0.1"